<template>
  <div class="video-wrap">
    <video-player :options="videoOptions" :poster="posterImage" :transcript="transcript" />
  </div>
</template>

<script>
import VideoPlayer from "../components/VideoPlayer.vue";
import Postar from "../assets/postar.png";
import Videofile from "../assets/waka_video.mp4";
import {transcriptData} from "../config/transcriptData.js"

export default {
  name: "VideoPlayer2",
  components: {
    VideoPlayer,
  },
  data() {
    return {
      posterImage: Postar, // Update with the URL of your poster image
      transcript: transcriptData,
      videoOptions: {
        autoplay: true,
        controls: true,
        sources: [
          {
            src: Videofile,
            type: "video/mp4",
          },
        ],
        tracks: [
          // Update property name to "tracks"
          {
            kind: "captions",
            src: "/src/assets/sub.vtt", // Update with the correct path to your subtitle file
            srclang: "en",
            label: "English",
            default: true, // auo play subtitle
          },
        ],
      },
    };
  },
};
</script>

<style scoped>
/* .video-wrap {
  position: relative;
  width: 100%;
} */
</style>
