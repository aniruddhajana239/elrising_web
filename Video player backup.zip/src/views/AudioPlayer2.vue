<template>
  <div class="video-wrap">
    <video-player :options="videoOptions" :poster="posterImage" :transcript="transcript" />
    <!-- <button @click="showRecorder = !showRecorder" class="record_control">Toggle Recorder</button> -->
  </div>
</template>

<script>
import VideoPlayer from "../components/VideoPlayer.vue";
import {transcriptData} from "../config/transcriptData.js"
import Postar from "../assets/postar.png";
import Audiofile from "../assets/waka_audio.mp3";

export default {
  name: "VideoPlayer2",
  components: {
    VideoPlayer,
  },
  data() {
    return {
      posterImage: Postar, // Update with the URL of your poster image
      transcript: transcriptData,
      videoOptions: {
        autoplay: true,
        controls: true,
        sources: [
          {
            src: Audiofile,
            type: "audio/mp3",
          },
        ],
        tracks: [
          // Update property name to "tracks"
          {
            kind: "captions",
            src: "/src/assets/sub.vtt", // Update with the correct path to your subtitle file
            srclang: "en",
            label: "English",
            default: true, // auo play subtitle
          },
        ],
      },
    };
  },
};
</script>

<style scoped>
 
</style>
