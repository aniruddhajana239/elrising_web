import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'VideoPlayer2',
      component: () => import('../views/VideoPlayer2.vue')
    },
    {
      path: '/audio-player2',
      name: 'AudioPlayer2',
      component: () => import('../views/AudioPlayer2.vue')
    },
  ]
})

export default router
