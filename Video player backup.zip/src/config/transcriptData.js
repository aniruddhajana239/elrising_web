const transcriptData = [
    {
      timestamp: 15,
      duration: 4,
      text: "Ooooh",
    },
    {
      timestamp: 19,
      duration: 2,
      text: "You're a good soldier",
    },
    {
      timestamp: 22,
      duration: 2,
      text: "Choosing your battles",
    },
    {
      timestamp: 24,
      duration: 3,
      text: "Pick yourself up and dust yourself off",
    },
    {
      timestamp: 28,
      duration: 2,
      text: "And back in the saddle",
    },
    {
      timestamp: 31,
      duration: 2,
      text: "You're on the front line",
    },
    {
      timestamp: 34,
      duration: 2,
      text: "Everyone's watching",
    },
    {
      timestamp: 36,
      duration: 1,
      text: "You know it's serious",
    },
    {
      timestamp: 38,
      duration: 2,
      text: "We're getting closer",
    },
    {
      timestamp: 41,
      duration: 2,
      text: "This isn't over",
    },
    {
      timestamp: 44,
      duration: 2,
      text: "The pressure's on",
    },
    {
      timestamp: 47,
      duration: 1,
      text: "You feel it",
    },
    {
      timestamp: 49,
      duration: 1,
      text: "But you got it all",
    },
    {
      timestamp: 51,
      duration: 1,
      text: "Believe it",
    },
    {
      timestamp: 53,
      duration: 3,
      text: "When you fall, get up, oh oh",
    },
    {
      timestamp: 56,
      duration: 2,
      text: "This time for Africa",
    },
    {
      timestamp: 59,
      duration: 3,
      text: "Listen to your God, this is our motto",
    },
    {
      timestamp: 63,
      duration: 2,
      text: "Your time to shine, don't wait in line",
    },
    {
      timestamp: 66,
      duration: 3,
      text: "Y vamos por todo",
    },
    {
      timestamp: 70,
      duration: 2,
      text: "People are raising their expectations",
    },
    {
      timestamp: 73,
      duration: 3,
      text: "Go on and feed them, this is your moment",
    },
    {
      timestamp: 77,
      duration: 2,
      text: "No hesitations",
    },
    {
      timestamp: 79,
      duration: 2,
      text: "Today's your day, I feel it",
    },
    {
      timestamp: 82,
      duration: 2,
      text: "You paved the way, believe it",
    },
    {
      timestamp: 85,
      duration: 3,
      text: "If you get down, get up, oh oh",
    },
    {
      timestamp: 89,
      duration: 3,
      text: "When you get down, get up, eh eh",
    },
    {
      timestamp: 93,
      duration: 3,
      text: "Tsamina mina eh eh",
    },
    {
      timestamp: 96,
      duration: 2,
      text: "Waka waka eh eh",
    },
    {
      timestamp: 99,
      duration: 3,
      text: "Tsamina mina eh eh",
    },
    {
      timestamp: 102,
      duration: 2,
      text: "Waka waka eh eh",
    },
    {
      timestamp: 105,
      duration: 3,
      text: "Tsamina mina eh eh",
    },
    {
      timestamp: 108,
      duration: 2,
      text: "Waka waka eh eh",
    }
  ]

  export {transcriptData}