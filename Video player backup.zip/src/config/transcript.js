// Load the transcript file

// Load the transcript file
export default function loadTranscript(data) {
  // fetch(data)
  //   .then(response => response.text())
  //   .then(data => {
      // Parse the transcript into an array of timestamps and text
      console.log('transcript data', data);
      const transcript = parseTranscript(data);
      console.log('transcript', transcript);

      // Create the transcript interface
      const transcriptElement = document.createElement('div');
      transcriptElement.className = 'transcript';
      transcript.forEach(line => {
        const lineElement = document.createElement('p');
        lineElement.textContent = line.text;
        lineElement.dataset.timestamp = line.timestamp;
        transcriptElement.appendChild(lineElement);
      });
      document.body.appendChild(transcriptElement);

      // Highlight the current transcript
      const videoElement = document.getElementById('video');
      videoElement.addEventListener('timeupdate', () => {
        const currentTime = videoElement.currentTime;
        const currentLine = transcript.find(line => line.timestamp <= currentTime && currentTime < line.timestamp + line.duration);
        const currentLineElement = transcriptElement.querySelector('.current');
        if (currentLineElement) {
          currentLineElement.classList.remove('current');
        }
        if (currentLine) {
          const lineElement = transcriptElement.querySelector(`[data-timestamp="${currentLine.timestamp}"]`);
          lineElement.classList.add('current');
        }
      });

      // Auto scroll the transcript
      transcriptElement.addEventListener('scroll', () => {
        const currentLineElement = transcriptElement.querySelector('.current');
        const nextLineElement = currentLineElement.nextElementSibling;
        if (nextLineElement) {
          const currentLineTop = currentLineElement.offsetTop - transcriptElement.offsetTop;
          const nextLineTop = nextLineElement.offsetTop - transcriptElement.offsetTop;
          if (currentLineTop < 0 || nextLineTop > transcriptElement.clientHeight) {
            transcriptElement.scrollTop = nextLineTop - transcriptElement.clientHeight / 2;
          }
        }
      });
    // });
}

function parseTranscript(data) {
  // Parse the transcript into an array of timestamps and text
  // Assumes a .vtt file format
  const lines = data.split('\n').filter(line => line.trim());
  return lines.filter(line => !line.includes('WEBVTT'))
    .map(line => {
      const [timestamp, arrow, text] = line.split(' ');
      const [hours, minutes, seconds, milliseconds] = timestamp.split(':').map(parseFloat);
      const duration = parseFloat(arrow) || 0;
      return {
        timestamp: hours * 3600 + minutes * 60 + seconds + milliseconds / 1000,
        duration,
        text
      };
    });
}
