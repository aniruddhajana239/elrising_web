<template>
  <div class="audio-recorder">
    <h1>Audio Recorder</h1>
    <div class="controls">
      <button @click="startRecording" :disabled="isRecording">
        Start Recording
      </button>
      <button @click="stopRecording" :disabled="!isRecording">
        Stop Recording
      </button>
      <button @click="playRecording" :disabled="!isRecording">
        Play Recording
      </button>
      <button
        @click="downloadRecording"
        :disabled="!isRecording || recordedChunks.length === 0"
      >
        Download Recording
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Recorder",
  data() {
    return {
      audioContext: null,
      mediaRecorder: null,
      recordedChunks: [],
      isRecording: false,
      recordedBlob: null,
    };
  },
  mounted() {
    this.initAudioContext();
  },
  methods: {
    initAudioContext() {
      this.audioContext = new AudioContext();
    },
    startRecording() {
      this.recordedChunks = [];
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then((stream) => {
          this.isRecording = true;
          this.mediaRecorder = new MediaRecorder(stream);
          this.mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
              this.recordedChunks.push(event.data);
            }
          };
          this.mediaRecorder.start();
        })
        .catch((error) => {
          console.error("Error accessing microphone:", error);
        });
    },
    stopRecording() {
      if (this.mediaRecorder && this.isRecording) {
        this.mediaRecorder.stop();
        this.mediaRecorder = null;
        this.isRecording = false;
        this.recordedBlob = new Blob(this.recordedChunks, {
          type: "audio/webm",
        });
        this.$emit("recorded", this.recordedChunks);
      }
    },
    playRecording() {
      if (this.recordedChunks.length === 0) {
        return;
      }
      const blob = new Blob(this.recordedChunks, { type: "audio/webm" });
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      audio.play();
    },
    downloadRecording() {
      if (this.recordedBlob) {
        const url = URL.createObjectURL(this.recordedBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "recording.webm";
        link.click();
        URL.revokeObjectURL(url);
      }
    },
  },
};
</script>

<style scoped>
.controls {
  display: flex;
  flex-direction: column;
}
</style>
