<template>
  <div class="video_player">
    <audio
      id="audio"
      ref="audioPlayer"
      class="video-js"
      muted
      :loop="loop"
    ></audio>

    <div class="playback_control_wrap">
      <div class="playback_speed_controls">
        <label for="playbackSpeed">Playback speed:</label>
        <select
          id="playbackSpeed"
          @change="setPlaybackSpeed($event.target.value)"
        >
          <option v-for="speed in playbackSpeeds" :key="speed" :value="speed">
            {{ speed }}x
          </option>
        </select>
      </div>
      <div class="loop_controls">
        <label for="loopCheckbox">Loop</label>
        <input type="checkbox" id="loopCheckbox" v-model="loop" />
      </div>
    </div>
  </div>
  <br />
  <div class="transcript">
    <div class="transcript_content">
      <div
        class="transcript_content_inner"
        v-for="(line, index) in transcript"
        :key="index"
        :class="{ highlighted: currentLineIndex === index }"
      >
        <p>
          <span
            v-for="word in line.text.split(' ')"
            @click="jumpToTimestamp(line.timestamp, word)"
            :key="word"
          >
            {{ word }}&nbsp;
          </span>
        </p>
        <div class="time" @click="seekToTimestamp(line.timestamp)">
          Duration: {{ line.duration }} || Timestamp: {{ line.timestamp }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import videojs from "video.js";
import videojs from "video.js/dist/video.min.js";
import "video.js/dist/video-js.min.css";

export default {
  name: "AudioPlayer",
  props: {
    options: {
      type: Object,
      default() {
        return {
          playbackSpeed: 1.0, // Default playback speed
        };
      },
    },
    poster: {
      type: String,
      default: "",
    },
    transcript: {
      type: Array,
      default: [],
    },
  },
  data() {
    return {
      player: null,
      playbackSpeeds: [0.5, 0.75, 1.5, 2.0], // Array of playback speed options
      currentTime: null, // Variable to store current time of audio
      currentLineIndex: null, // Variable to store current transcript line index
      loop: false,
    };
  },
  mounted() {
    this.initializePlayer();
  },
  beforeDestroy() {
    if (this.player) {
      this.player.dispose();
    }
  },
  watch: {
    options: {
      handler() {
        this.initializePlayer();
      },
      deep: true,
    },
    poster() {
      if (this.player) {
        this.player.poster(this.poster);
      }
    },
    loop(newVal) {
      if (this.player) {
        this.player.loop(newVal);
      }
    },
  },
  methods: {
    // controllers can be handeled from here
    initializePlayer() {
      if (this.player) {
        this.player.dispose();
      }
      this.player = videojs(this.$refs.audioPlayer, this.options, () => {
        this.player.log("onPlayerReady", this);
        this.player.on("timeupdate", this.updateCurrentTime); // Listen for timeupdate event to update current time
        const fullscreenToggle =
          this.player.controlBar.getChild("FullscreenToggle");
        if (fullscreenToggle) {
          this.player.controlBar.removeChild(fullscreenToggle);
        }
      });
      this.player.poster(this.poster);
      this.setPlaybackSpeed(this.options.playbackSpeed); // Set initial playback speed
    },

    setPlaybackSpeed(speed) {
      this.player.playbackRate(speed);
    },
    seekToTimestamp(timestamp) {
      this.player.currentTime(timestamp);
    },
    jumpToTimestamp(timestamp, word) {
      const wordClicked = word.trim(); // Extract the specific word clicked by trimming the whitespace
      const line = this.transcript.find((line) => line.timestamp === timestamp); // Find the line in the transcript based on the timestamp
      if (line) {
        const text = line.text;
        window.open(
          `https://dict.naver.com/search.nhn?dicQuery=${wordClicked}&query=${wordClicked}&target=dic&ie=utf8&query_utf=&isOnlyViewEE=`,
          "_blank"
        );
      }
    },
    updateCurrentTime() {
      this.currentTime = this.player.currentTime(); // Update current time of audio

      // Find the current transcript line index based on the current time of audio
      const lineIndex = this.transcript.findIndex(
        (line) =>
          line.timestamp <= this.currentTime &&
          line.duration + line.timestamp > this.currentTime
      );

      // If the current transcript line index has changed, update the currentLineIndex data property
      if (lineIndex !== this.currentLineIndex) {
        this.currentLineIndex = lineIndex;
      }
    },
  },
};
</script>

<style lang="css" scoped>
.video-js {
  width: 100%;
  height: 350px;
}

.playback_speed_controls {
  display: flex;
  justify-content: flex-start;
  margin-top: 10px;
}
.playback_speed_controls label {
  margin-right: 5px;
}
.subtitle {
  cursor: pointer;
}
.transcript_content_inner .time,
.transcript_content_inner p {
  cursor: pointer;
}
.transcript_content_inner .time {
  color: #969696;
}
.highlighted {
  color: #08a6d7;
}
#playbackSpeed {
  border: 1px solid #969696;
  padding: 0px 5px;
}
.playback_control_wrap {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.loop_controls label {
  margin-right: 10px;
}
@media screen and (max-width: 590px) {
  .video-js {
    height: 220px;
  }
}
</style>
