<template>
  <header>
    <nav>
      <RouterLink
        to="/"
        :class="{ active: activeItem === 'video' }"
        @click="setActiveItem('video')"
        >Video Player</RouterLink
      >
      <RouterLink
        to="/audio-player2"
        :class="{ active: activeItem === 'audio' }"
        @click="setActiveItem('audio')"
        >Audio Player</RouterLink
      >
      <!-- <RouterLink
        to="/recorder"
        :class="{ active: activeItem === 'recorder' }"
        @click="setActiveItem('recorder')"
        >Recorder</RouterLink
      > -->
    </nav>
  </header>
</template>

<script>
export default {
  data() {
    return {
      activeItem: null,
    };
  },
  methods: {
    setActiveItem(item) {
      this.activeItem = item;
    },
  },
  mounted() {
    // Set 'video' as the default active item when the component is mounted
    this.activeItem = 'video';
  }
};
</script>

<style scoped>
header {
  padding: 15px;
  box-shadow: 0 3px 9px 0px rgba(0, 0, 0, 0.1);
  justify-content: center;
}
nav {
  display: flex;
  justify-content: center;
}
nav a {
  color: #969696;
  text-decoration: none;
  padding: 0 15px;
}
.active {
  color: #26497a;
  border-bottom: 2px solid #26497a;
}
</style>
