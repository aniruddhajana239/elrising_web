<script setup>
import { RouterLink, RouterView } from "vue-router";
import Header from "./components/Header.vue";
</script>

<template>
  <v-container>
   <v-row justify="center">
    <v-col sm="6" xs="12">
      <Header />
      <router-view :key="$route.path" v-slot="{ Component }">
        <transition name="route" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </v-col>
   </v-row>
  </v-container>

</template>

<style>
.video-wrap {
  display: flex;
  flex-direction: column;
}

.video-wrap .video_player {
  order: 1;
}

.video-wrap .record_control {
  order: 2;
}

 .video-wrap .transcript {
  order: 3;
}
</style>
