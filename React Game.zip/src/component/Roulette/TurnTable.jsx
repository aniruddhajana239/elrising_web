"use client";

import React, { useEffect, useState } from "react";
import ReactTurntable from "react-turntable";
import "react-turntable/assets/index.css";

const styles = {
  justifyContent: "center",
  alignContent: "center",
  display: "flex",
};
// const prizes = [
//   "MI",
//   "Meizu",
//   "iphone 6s",
//   "iphone 6s plus",
//   "Chafingdish",
//   "WeiLong",
//   "Bikram",
//   "Why this"
// ];

const TurnTable = ({ setWinner, setShow, setConfettiState }) => {
  const [prizes, setPrizes] = useState([]);
  const handleShow = () => {
    setShow(true);
    setConfettiState(true);
  };

  useEffect(() => {
    let prize = [
      "MI",
      "Meizu",
      "iphone 6s",
      "iphone 6s ",
      "Chafingdish",
      "WeiLong",
      "iphone x",
      "movie ticket",
    ];
    setPrizes(prize);
  }, []);

  const options = {
    prizes,
    width: 700,
    height: 700,
    primaryColor: "#fa503b",
    secondaryColor: "#31c27c",
    fontStyle: {
      color: "#fff",
      size: "24px",
      fontVertical: false,
      fontWeight: "bold",
      fontFamily: "Microsoft YaHei",
      padding: "15px",
    },
    speed: 1000,
    duration: 5000,
    clickText: "Start",
    onStart() {
      //If you want before the rotate do some...
      console.log("start...");
      //If you want stop rotate you can return false
      return true;
    },
    onComplete(prize) {
      console.log("prize:", prize);
      setWinner(prize);
      handleShow();
    },
  };

  return (
    <div style={styles}>
      {prizes.length > 2 ? <ReactTurntable {...options} /> : <></>}
    </div>
  );
};

export default TurnTable;
