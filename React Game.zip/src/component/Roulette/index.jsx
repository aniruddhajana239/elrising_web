"use client";

import React, { useEffect } from "react";
import TurnTable from "./TurnTable";
import Confetti from "../Confetti/index";
import { useState } from "react";
import useWindowSize from "react-use/lib/useWindowSize";

const Roulette = () => {
  const [winner, setWinner] = useState("");
  const [show, setShow] = useState(false);
  const [confettiState, setConfettiState] = useState(false);
  const { width, height } = useWindowSize();

  useEffect(() => {
    if (confettiState) {
      setTimeout(() => {
        setConfettiState(false);
      }, 7000);
    }
  }, [confettiState]);
  return (
    <section>
      {/* {width} */}

      <Confetti width={confettiState ? width - 20 : 0} height={confettiState ? height : 0} />
      <TurnTable
        setWinner={setWinner}
        setShow={setShow}
        setConfettiState={setConfettiState}
      />

      <p className="Winner-roullette">You won - {winner}</p>
      {/* {confettiState ? "confetti" : "non-confetti"} */}
    </section>
  );
};

export default Roulette;
