import Confetti from "react-confetti";

const ConfettiComp = ({ width, height }) => {
  return <Confetti width={width} height={height} />;
};

export default ConfettiComp;
