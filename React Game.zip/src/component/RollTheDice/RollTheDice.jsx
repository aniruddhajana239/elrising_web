import React, { useState } from "react";
import Image from 'next/image';
import WinImage from "../../assets/images/win_gmae.gif";
import oneDice from "../../assets/images/oneDice.png";
import twoDice from "../../assets/images/twoDice.png";
import threeDice from "../../assets/images/threeDice.png";
import fourDice from "../../assets/images/fourDice.png";
import fiveDice from "../../assets/images/fiveDice.png";
import sixDice from "../../assets/images/sixDice.png";


function RollTheDice() {
  const [diceCount, setDiceCount] = useState(2);
  const [diceValues, setDiceValues] = useState(Array.from({ length: diceCount }, () => 1));
  const [win, setWin] = useState(false)

  function rollDice() {
    setWin(false)
    const newDiceValues = Array.from({ length: diceCount }, () => Math.floor(Math.random() * 6 + 1));
    setDiceValues(newDiceValues);
    // Add "rolling" class to each dice to trigger rotation animation
    const diceElements = document.querySelectorAll('.dice');
    diceElements.forEach((diceElement) => {
      diceElement.classList.add('rolling');
    });
    // Remove "rolling" class after a short delay to allow animation to complete
    setTimeout(() => {
      diceElements.forEach((diceElement) => {
        diceElement.classList.remove('rolling');
      });
      // Check if all dice have the same value and declare the user as the winner if that is the case
      if (newDiceValues.every((value) => value === newDiceValues[0])) {
        setWin(true)
      }
    }, 1000);
  }
  
  

  function handleDiceCountChange(event) {
    setDiceCount(parseInt(event.target.value));
    setDiceValues(Array.from({ length: parseInt(event.target.value) }, () => 1));
    setWin(false)
  }

  return (
    <div className="game">
      <div className="dice_container dice_select_wrap">
        {/* <label>Set the Dice</label>
        <select value={diceCount} onChange={handleDiceCountChange} className="dice_select">
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select> */}
      </div>
      <div className="dice_container">
        {diceValues.map((value, index) => (
          <div key={`dice-${index+1}`} className={`dice dice-${index+1} show-${value}`} id={`dice${index+1}`}>
            <div id={`dice-${index+1}-side-one`} className="side one">
              <Image src={oneDice} width={320} height={150} alt="" />
              {/* <div className="dot one-1"></div> */}
            </div>
            <div id={`dice-${index+1}-side-two`} className="side two">
              {/* <div className="dot two-1"></div>
              <div className="dot two-2"></div> */}
              <Image src={twoDice} width={320} height={150} alt="" />
            </div>
            <div id={`dice-${index+1}-side-three`} className="side three">
              {/* <div className="dot three-1"></div>
              <div className="dot three-2"></div>
              <div className="dot three-3"></div> */}
              <Image src={threeDice} width={320} height={150} alt="" />
            </div>
            <div id={`dice-${index+1}-side-four`} className="side four">
              {/* <div className="dot four-1"></div>
              <div className="dot four-2"></div>
              <div className="dot four-3"></div>
              <div className="dot four-4"></div> */}
              <Image src={fourDice} width={320} height={150} alt="" />
            </div>
            <div id={`dice-${index+1}-side-five`} className="side five">
              {/* <div className="dot five-1"></div>
              <div className="dot five-2"></div>
              <div className="dot five-3"></div>
              <div className="dot five-4"></div>
              <div className="dot five-5"></div> */}
              <Image src={fiveDice} width={320} height={150} alt="" />
            </div>
            <div id={`dice-${index+1}-side-six`} className="side six">
              {/* <div className="dot six-1"></div>
              <div className="dot six-2"></div>
              <div className="dot six-3"></div>
              <div className="dot six-4"></div>
              <div className="dot six-5"></div>
              <div className="dot six-6"></div> */}
              <Image src={sixDice} width={320} height={150} alt="" />
            </div>
          </div>
        ))}
      </div>
      {win && 
      <div className="dice_win_wrap">
        <Image src={WinImage} width={320} height={150} alt="" />
      <p className="dice_win">Jackpot!</p>
      </div>
      }
      <div id='roll' class='opponent-choose' onClick={rollDice}><button>Roll dice!</button></div>
    </div>
  );
}

export default RollTheDice
