import React from 'react';
import Modal from "../Modal/Modal"

const SearchApiModal = () => {
  return (
    <div className='modal'>
        <div className='modal-backdrop'></div>
      
    </div>
  )
}

export default SearchApiModal
