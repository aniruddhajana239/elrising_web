import React, { useState } from "react";

const MysteryBoxGame = () => {
  const [result, setResult] = useState("");
  const [boxCount, setBoxCount] = useState(3);
  const [gameResult, setGameResult] = useState("");

  const openBox = (event) => {
    // get the clicked box element
    const clickedBox = event.target;
    
    // generate a random number between 1 and 100
    const randomNumber = Math.floor(Math.random() * 100) + 1;
  
    // create an array of box results, with some set to "win" and the rest to "empty"
    const boxResults = [];
    for (let i = 0; i < boxCount; i++) {
      if (i === 0) {
        boxResults.push("win");
      } else {
        boxResults.push("empty");
      }
    }
  
    // shuffle the box results
    for (let i = boxCount - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [boxResults[i], boxResults[j]] = [boxResults[j], boxResults[i]];
    }
  
    // update the class of the clicked box based on the corresponding box result
    const clickedBoxIndex = Array.from(clickedBox.parentNode.children).indexOf(clickedBox);
    const clickedBoxResult = boxResults[clickedBoxIndex];
    if (clickedBoxResult === "win") {
      clickedBox.classList.remove("default");
      clickedBox.classList.add("win");
      setResult("Congratulations, you won a prize!");
      setGameResult("win");
    } else {
      clickedBox.classList.remove("default");
      clickedBox.classList.add("empty");
      setResult("Sorry, you have choose an empty box.");
      setGameResult("lose");
    }
  
    // update the class of all other boxes based on their corresponding box result
    const boxes = document.querySelectorAll(".box");
    boxes.forEach((box, index) => {
      if (index !== clickedBoxIndex) {
        const boxResult = boxResults[index];
        if (boxResult === "win") {
          box.classList.remove("default");
          box.classList.add("win");
        } else {
          box.classList.remove("default");
          box.classList.add("empty");
        }
      }
    });
  };
  
  

  const handleBoxCountChange = (event) => {
    // get the new box count from the dropdown menu
    const newBoxCount = parseInt(event.target.value);
    restartGame();
    // update the box count state variable
    setBoxCount(newBoxCount);
    // reset game result
    setGameResult("");
  };

  const restartGame = () => {
    // reset the result and box classes
    setResult("");
    const boxes = document.querySelectorAll(".box");
    boxes.forEach((box) => {
      box.classList.remove("win");
      box.classList.remove("empty");
      box.classList.add("default");
    });
    // reset game result
    setGameResult("");
  };

  // create an array of box elements based on the box count state variable
  const boxes = [];
  for (let i = 1; i <= boxCount; i++) {
    boxes.push(<div key={i} className="box default" onClick={openBox}></div>);
  }

  return (
    <div className="game_wrap">
      <h1 className="game_title">Mystery Box Game</h1>
      <p>Click a box to reveal what's inside:</p>
      <div className="box_select_wrap">
        {/* <label htmlFor="box-count">Number of boxes:</label>
        <select id="box-count" value={boxCount} onChange={handleBoxCountChange}>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
        </select> */}
      </div>
      <div className="box_wrap">{boxes}</div>
      <div className="result_restart">
        <h2> result : {result}</h2>
        <button onClick={restartGame} className="btn_white_border">Restart Game</button>
      </div>
      {gameResult === "" ? null : (
        <h2 className="overall_score">
          {gameResult === "win" ? "You won!" : "You lost :("}
        </h2>
      )}
    </div>
  );
};

export default MysteryBoxGame;
