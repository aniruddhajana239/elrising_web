import React from 'react'

const Modal = ({modalSize, Header, children, Footer}) => {
  return (
    <div className={`modal-backdrop ${modalSize ? '' : ''}`}>
      <div
        className={`modal ${modalSize ? modalSize : ''}`}
        role="dialog"
        aria-labelledby="modalTitle"
        aria-describedby="modalDescription"
      >
        <header className="modal-header" id="modalTitle">
          {Header}
        </header>

        <section className="modal-body" id="modalDescription">
          {children}
        </section>

        <footer className="modal-footer">
          {Footer}
        </footer>
      </div>
    </div>
  )
}

export default Modal