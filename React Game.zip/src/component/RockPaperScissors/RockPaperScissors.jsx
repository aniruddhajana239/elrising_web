import React, { useState } from 'react';
import Image from 'next/image';
import rockImg from "../../assets/images/rock.jpg";
import paperImg from "../../assets/images/paper.jpg";
import scissorImg from "../../assets/images/scissor.jpg";

function RockPaperScissors() {
  const [playerScore, setPlayerScore] = useState(0);
  const [computerScore, setComputerScore] = useState(0);
  const [opponentMove, setOpponentMove] = useState(null);
  const [result, setResult] = useState(null);

  const handleMoveClick = (yourMove) => {
    const opponentMove = generateRandomOpponentMove();
    setOpponentMove(opponentMove);
    calculateWinner(yourMove, opponentMove);
  };

  const generateRandomOpponentMove = () => {
    const availableMoves = ['rock', 'paper', 'scissors'];
    const randomNumber = Math.floor(Math.random() * availableMoves.length);
    const opponentMove = availableMoves[randomNumber];

    return opponentMove;
  };

  const calculateWinner = (yourMove, opponentMove) => {
    switch (yourMove) {
      case 'rock':
        if (opponentMove === 'rock') {
          showResult('draw');
        } else if (opponentMove === 'scissors') {
          youWin();
        } else {
          youLose();
        }
        break;
      case 'paper':
        if (opponentMove === 'paper') {
          showResult('draw');
        } else if (opponentMove === 'rock') {
          youWin();
        } else {
          youLose();
        }
        break;
      case 'scissors':
        if (opponentMove === 'scissors') {
          showResult('draw');
        } else if (opponentMove === 'paper') {
          youWin();
        } else {
          youLose();
        }
        break;
    }
  };

  const youWin = () => {
    setPlayerScore(playerScore + 1);
    showResult('win');
  };

  const youLose = () => {
    setComputerScore(computerScore + 1);
    showResult('lose');
  };

  const showResult = (result) => {
    setResult(result);
  };

  return (
    <div className="App">
      {result && (<p className="rps-ans">You {result}!</p>)}
      <ul id="moves">
        <li data-move="rock" onClick={() => handleMoveClick('rock')}>
          <Image src={rockImg} width={180} height={180} alt='' />
          <span className="text">Rock</span>
        </li>
        <li data-move="paper" onClick={() => handleMoveClick('paper')}>
        <Image src={paperImg} width={180} height={180} alt='' />
          <span className="text">Paper</span>
        </li>
        <li data-move="scissors" onClick={() => handleMoveClick('scissors')}>
        <Image src={scissorImg} width={180} height={180} alt='' />
          <span className="text">Scissors</span>
        </li>
      </ul>
      <div className="scoreboard">
        <table>
          <thead>
            <tr>
              <th>Player</th>
              <th>Computer</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="Player-count">{playerScore}</td>
              <td className="Computer-count">{computerScore}</td>
            </tr>
          </tbody>
        </table>
        {opponentMove && (<p className="opponent-choose">Opponent chose {opponentMove}.</p>)}
      </div>
    </div>
  );
}

export
 default RockPaperScissors;
