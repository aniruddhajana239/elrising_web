import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";

const Wheel = dynamic(() => import("react-custom-roulette").then((mod) => mod.Wheel),
  {
    ssr: false,
  }
);

const SpinGame = () => {
  const [mustSpin, setMustSpin] = useState(false);
  const [prizeNumber, setPrizeNumber] = useState(0);
  const [isSpinningComplete, setIsSpinningComplete] = useState(false);

  const data = [
    {
      option:
        "0",
      image: {
        uri: "https://ik.imagekit.io/uwvco4rxfsf/2_wYt-Bj6vu.png?updatedAt=1684404494981",
      },
    },
    {
      option: "1",
      image: {
        uri: "https://ik.imagekit.io/uwvco4rxfsf/4_Qdd75y2xi.png?updatedAt=1684408150238",
      },
    },
    {
      option: "2",
      image: {
        uri: "https://ik.imagekit.io/uwvco4rxfsf/3_8aEq12GtL.png?updatedAt=1684408097691",
      },
    },
    {
      option: "3",
      image: {
        uri: "https://ik.imagekit.io/uwvco4rxfsf/2_d79MHU_l2.png?updatedAt=1684408097516",
      },
    },
  ];

  const handleSpinClick = () => {
    if (!mustSpin) {
      const newPrizeNumber = Math.floor(Math.random() * data.length);
      setPrizeNumber(newPrizeNumber);
      setMustSpin(true);
      setIsSpinningComplete(false);
    }
  };

  useEffect(() => {
    // Accessing window object or performing any other client-side operations
  }, []);

  const handleStopSpinning = () => {
    setIsSpinningComplete(true);
  };

  return (
    <>
      <div className="spn_wraper">
        <Wheel
          mustStartSpinning={mustSpin}
          prizeNumber={prizeNumber}
          data={data}
          onStopSpinning={() => {
            setMustSpin(false);
            handleStopSpinning();
          }}
          pointerAlign="center"
        />
        <button onClick={handleSpinClick} className="spin_btn">
          SPIN
        </button>
      </div>
      {isSpinningComplete && (
        <p>
          Winning slice: {data[prizeNumber].option} - Prize:{" "}
          {data[prizeNumber].image.uri}
        </p>
      )}
    </>
  );
};

export default SpinGame;