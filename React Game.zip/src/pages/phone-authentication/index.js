import { useEffect, useState } from "react";
import axios from "axios";

const Index = () => {
  const [mobileEncryptData, setMobileEncryptData] = useState(undefined);
  useEffect(() => {
    var eventMethod = window.addEventListener
      ? "addEventListener"
      : "attachEvent";
    var eventer = window[eventMethod];
    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
    eventer(
      messageEvent,
      function (e) {
        if (e?.data?.mobileno) {
          document.getElementById("phoneNumber").value =
            e?.data?.mobileno || "";
        }
      },
      false
    );
  }, []);

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    let client_id = "G0723";
    let client_secret = "0S6ZT2AYXPFY";
    let token = btoa(`${client_id}":"${client_secret}`)
    let res = await axios.post(
      `https://svc.niceapi.co.kr:22001/digital/niceid/oauth/oauth/token HTTP/1.1`,
      {
        headers: {
          params: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          Authorization:
            "Basic " + token,
        },
      }
    );
    console.log("token", res);
  };

  const fnPopup = () => {
    window.open(
      "",
      "popupChk",
      "width=500, height=350, top=100, left=100, fullscreen=no, menubar=no, status=no, toolbar=no, titlebar=yes, location=no, scrollbar=no"
    );
    document.form_chk.action =
      "https://nice.checkplus.co.kr/CheckPlusSafeModel/checkplus.cb";
    document.form_chk.target = "popupChk";
    // document.post;
    document.form_chk.submit();
  };

  return (
    <form name="form_chk" method="post" target="popupChk">
      <input type="hidden" name="m" value="checkplusService" />
      <input type="hidden" name="EncodeData" value={mobileEncryptData} />
      <input type="text" id="phoneNumber" value="" />
      <div class="btn-grp button">
        <button onClick={fnPopup} id="formPopUp" class="btn btn-primary m-4">
          확인
        </button>
      </div>
      {mobileEncryptData}
    </form>
  );
};

export default Index;
