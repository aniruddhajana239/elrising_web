import { Inter } from "next/font/google";
import MysteryBoxGame from "@/component/MysteryBoxGame/MysteryBoxGame";
// import Roulette from "@/component/Roulette/Roulette";
// import TicTacToe from "@/component/TicTacToe/TicTacToe";
// import Roulette from "@/component/Roulette/index";
// import CustomRoulette from "@/component/Roulette/CustomRoulette";
// import RockPaperScissors from "@/component/RockPaperScissors/RockPaperScissors";
import RollTheDice from "@/component/RollTheDice/RollTheDice";
// import SpinGame from "@/component/Spin/Spin";
const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  return (
    <main
      className={`flex min-h-screen flex-col items-center justify-between p-24 ${inter.className}`}
    >
      {/* <h1>Next APP</h1> */}
      {/* <RockPaperScissors /> */}
      {/* <MysteryBoxGame /> */}
      {/* <Roulette /> */}
      {/* <TicTacToe/> */}
      {/* <Roulette /> */}
      {/* <CustomRoulette /> */}
      <RollTheDice/>
      {/* <SpinGame /> */}
    </main>
  );
}
