import React, { useState } from "react";
import axios from "axios";
import Modal from "@/component/Modal/Modal";

const SearchAPI = () => {
  const [addressContents, setAddressContents] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [pagination, setPagination] = useState({
    page: 1,
    totalCount: 0,
  });
  const [openSearchModal, setOpenSearchModal] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState({});
  const [selectedId, setSelectedId] = useState(-1);

  const setDetailed = (addr) => {
    selectedAddress.detailedAddress = addr;
    setSelectedAddress(selectedAddress);
  };

  const showSelected = () => {
    console.log("selected address", selectedAddress);
    setOpenSearchModal(false);
    setSelectedId(-1);
  };

  const OpenSearchModal = () => {
    setOpenSearchModal(true);
    setSelectedAddress({});
  };

  const handleSearch = (e) => {
    e.preventDefault();
    axios
      .get("https://business.juso.go.kr/addrlink/addrLinkApi.do", {
        params: {
          confmKey: "TESTJUSOGOKR",
          currentPage: 1,
          countPerPage: 10,
          useDetailAddr: "y",
          keyword: searchText,
          resultType: "json",
        },
      })
      .then((response) => {
        if (response.data.results.common.errorCode === "0") {
          setAddressContents(response.data.results.juso);
        } else {
          setAddressContents([]);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };
  return (
    <div className="address-verification">
      <h1 className="text-center mb-5 h1">Address Search</h1>
      <form>
        <input
          type="text"
          className="form-control"
          placeholder="Street name address"
          value={selectedAddress.roadAddr}
          readOnly
        />
        <input
          type="text"
          className="form-control"
          placeholder="Zip code"
          value={selectedAddress.zipNo}
          readOnly
        />
        <input
          type="text"
          className="form-control"
          placeholder="Detailed Address"
          value={selectedAddress.detailedAddress}
          readOnly
        />
        <div className="text-center">
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => OpenSearchModal()}
          >
            Search now
          </button>
        </div>
      </form>

      {openSearchModal && (
        <Modal>
          <div className="korea-post-address-search">
            <form onSubmit={handleSearch}>
              <input
                type="text"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                placeholder="Enter an address"
              />
              <button type="submit">Search</button>
            </form>
            {selectedId > -1 ? (
              <div>
                <input
                  type="text"
                  placeholder="detailed Address"
                  onChange={(e) => setDetailed(e.target.value)}
                />
                <button type="button" onClick={showSelected}>
                  Submit
                </button>
              </div>
            ) : (
              <ul>
                {addressContents.map((result, index) => (
                  <li
                    key={index}
                    onClick={() => {
                      setSelectedAddress(result), setSelectedId(index);
                    }}
                  >
                    <div>{result.engAddr}</div>
                    <div>{result.roadAddr}</div>
                    <div>{result.zipNo}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default SearchAPI;
