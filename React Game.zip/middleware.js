import { NextResponse } from "next/server";

export default function middleware(req) {
  let verify = false;
  let url = req.url;
  let protectedRoutes = ['phone-authentication']
  if(!verify && protectedRoutes.includes(url)) {
    NextResponse.redirect("/")
  }
}
