// jest.config.js
module.exports = {
  testEnvironment: "jest-environment-jsdom-global",
};
